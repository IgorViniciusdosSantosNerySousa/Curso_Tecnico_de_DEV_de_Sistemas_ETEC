package ExemploEstrutura1;

public class ExemploDeSelecao2 {

	public static void main(String[] args) {
	  //fa�a um programa que leia 4 notas de um aluno

	}

}
