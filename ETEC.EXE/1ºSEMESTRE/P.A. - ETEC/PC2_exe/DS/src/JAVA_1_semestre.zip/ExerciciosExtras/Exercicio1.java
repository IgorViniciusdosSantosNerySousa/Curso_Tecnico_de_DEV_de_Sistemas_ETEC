package ExerciciosExtras;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		
		
		
	}
	
}