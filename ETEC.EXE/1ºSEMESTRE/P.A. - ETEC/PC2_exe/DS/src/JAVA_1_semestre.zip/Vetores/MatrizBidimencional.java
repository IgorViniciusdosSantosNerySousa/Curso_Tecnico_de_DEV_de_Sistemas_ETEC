package Vetores;

import java.util.Scanner;

public class MatrizBidimencional {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner (System.in);
		int
	}

}
