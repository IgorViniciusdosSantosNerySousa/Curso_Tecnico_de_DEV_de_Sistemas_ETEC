package Lista2;

public class i11 {

public static void main(String[] args) {
        int total = 0;
        int i=0;
        
        
        for (i = 0; i <= 100; i++) {
            total +=i;
            System.out.println(total);
        }

        
    }
}
