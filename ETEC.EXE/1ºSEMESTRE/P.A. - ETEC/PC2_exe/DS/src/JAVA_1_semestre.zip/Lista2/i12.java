package Lista2;

import java.util.Scanner;

public class i12 {

	public static void main(String[] args) {
		
		Scanner leia=new Scanner (System.in);
		int numImpar;
		
        for (numImpar = 0; numImpar <= 50; numImpar++) {
            if (numImpar % 2 != 0) {
                System.out.println(numImpar);
            }
            
        }//fim for

	}

}
