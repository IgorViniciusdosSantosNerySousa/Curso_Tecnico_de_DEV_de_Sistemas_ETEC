package Lista3;

public class J1 {

	public static void main(String[] args) {
	int numero = 0;

	System.out.println("Ordem crescente :" );
	while (numero <=100) {
		
		System.out.println(+ numero);
		numero++;
	}
	System.out.println("_____________________________________________________________________________________");
	System.out.println("Ordem decrescente :" );
	
	while (numero>=1) {
		System.out.println(numero -1);
		numero--;
	
	
	}

	}

}
