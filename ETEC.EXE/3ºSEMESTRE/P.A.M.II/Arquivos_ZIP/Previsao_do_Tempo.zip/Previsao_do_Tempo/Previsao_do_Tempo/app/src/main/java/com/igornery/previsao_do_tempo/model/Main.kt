package com.igornery.previsao_do_tempo.model

import org.json.JSONObject

data class Main {
    val main: JSONObject,
    val sys: JSONObject,
    val weather: List<Weather>,
    val name: String,

}