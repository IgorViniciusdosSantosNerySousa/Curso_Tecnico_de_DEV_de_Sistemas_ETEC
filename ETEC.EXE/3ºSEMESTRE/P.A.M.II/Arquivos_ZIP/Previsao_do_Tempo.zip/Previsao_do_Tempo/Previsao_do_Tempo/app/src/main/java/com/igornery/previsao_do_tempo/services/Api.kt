package com.igornery.previsao_do_tempo.services

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.QUERY
import com.igornery.previsao_do_tempo.model.Main


//https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}
//713c6c50f056fee3480890a82e2f951c < chave API


interface Api {

    @GET("weather")

    fun weatherMap(
        @Query ("q") cityName: String,
        @Query ("appid") api_key: String
    ): Call<Main>
}