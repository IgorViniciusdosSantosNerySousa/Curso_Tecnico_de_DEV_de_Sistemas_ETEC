package com.igornery.previsao_do_tempo

import android.icu.text.DecimalFormat
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.igornery.previsao_do_tempo.constantes.Const
import com.igornery.previsao_do_tempo.model.Main
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        }

    override fun onResume() {
        super.onResume()

        binding.progressBar.visibilty = View.VISIBLE

        val retrofit = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .build()
            .create(Api::class.java)

        retrofit.weatherMap("São Paulo", Const.API_KEY).enqueue(object : Callback<Main>{
            override fun onResponse(call: Call<Main>, response: Response<Main>) {
                if(response.isSuccessful){
                    respostaServidor(response)
                }else{
                    Toast.makeText(applicationContext, "Cidade Inválida!", Toast.LENGTH_SHORT).show()
                    binding.progressBar.visibilty = View.GONE
                }
            }

            override fun onFailure(call: Call<Main>, t: Throwable) {
                Toast.makeText(applicationContext, "Erro fatal de Servidor!", Toast.LENGTH_SHORT).show()
                binding.progressBar.visibilty = View.GONE
            }

        })
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun respostaServidor(response: Response<Main>){

        val main = response.body()!!.main
        val temp = main.get("temp").toString()
        val tempMin = main.get("temp_min").toString()
        val tempMax = main.get("temp_max").toString()
        val humidity = main.get("humidity").toString()

        val sys = response.body()!!.sys
        val country = main.get("country").toString()

        val weather = response.body()!!.weather
        val main_weather = weather[0].main
        val description = weather[0].description
        val name = response.body()!!.name

        //CONVERTER KELVIN EM GRAUS CELSIUS - FÓRMULA: 298 - 273,15 = 26.85C

        val temp_c = (temp.toDouble() - 273.15)
        val tempMin_c = (tempMin.toDouble() - 273.15)
        val tempMax_c = (tempMax.toDouble() - 273.15)
        val decimalFormat = DecimalFormat("00")

        binding.txtTemperatura.setText("${decimalFormat.format(temp_c)}ºC")
        binding.txtPaisCidade.setText("$country - $name")

        binding.txtinformacoes1.setText("Clima \n $description \n\n Umidade \n $humidity")
        binding.txtInformacoes2.settext("Temp.Min \n ${decimalFormat.format(tempMin_c)} \n\n Temp.Max \n ${decimalFormat.format(tempMax_c)}")

        binding.progressBar.visibility = View.GONE
    }
}


