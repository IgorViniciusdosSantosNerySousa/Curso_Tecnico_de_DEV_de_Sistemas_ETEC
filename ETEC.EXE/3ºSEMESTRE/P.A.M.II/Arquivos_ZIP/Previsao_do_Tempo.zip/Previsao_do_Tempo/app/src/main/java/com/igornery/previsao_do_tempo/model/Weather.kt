package com.igornery.previsao_do_tempo.model

data class Weather {
    val main: String,
    val description: String
}