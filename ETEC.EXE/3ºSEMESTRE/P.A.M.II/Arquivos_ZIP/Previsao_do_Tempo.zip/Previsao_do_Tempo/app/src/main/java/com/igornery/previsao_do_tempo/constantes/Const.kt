package com.igornery.previsao_do_tempo.constantes

object Const {
    const val API_KEY = "713c6c50f056fee3480890a82e2f951c"

}