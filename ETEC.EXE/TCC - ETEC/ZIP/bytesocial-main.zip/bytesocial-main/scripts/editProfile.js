function editProfile() {
/*na tela profile, ao clicar no botão editar os campos background,
userPic, userVocation e txtBio poderão ser alterados

e o botão editar mudrá o nome para salvar 

precisará criar uma verificação para que quando o nome do botão for salvar 
alterar as informações
*/
}