# bytesocial
instância final do byte
