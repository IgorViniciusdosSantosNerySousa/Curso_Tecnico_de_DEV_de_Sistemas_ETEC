# bytedb_experimental
recriação experimental do banco de dados byte, focado em views e triggers, deixando de lado as procedures em favor do desenvolvimento
