<?php
    // experimental

    require_once 'backend.php';

    if ( isset($_GET['id_post']) )
    {
        
    }
    else
    {
        
    }