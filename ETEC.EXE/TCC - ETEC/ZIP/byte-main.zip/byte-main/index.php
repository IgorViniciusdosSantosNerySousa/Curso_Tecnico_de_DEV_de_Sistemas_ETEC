<?php
    header("Location: landingPage.php");