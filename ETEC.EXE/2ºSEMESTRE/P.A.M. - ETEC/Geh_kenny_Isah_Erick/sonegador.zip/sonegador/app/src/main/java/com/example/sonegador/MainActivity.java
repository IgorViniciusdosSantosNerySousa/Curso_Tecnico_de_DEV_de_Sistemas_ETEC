package com.example.sonegador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText moeda;
Button btnsonegar;
TextView txtresult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        moeda = findViewById(R.id.enterCoin);
        btnsonegar = findViewById(R.id.sonegare);
        txtresult = findViewById(R.id.hide);

        btnsonegar.setOnClickListener(v -> {
            sonegar();
        });
    }

        private void sonegar(){
            String BRL = moeda.getText().toString();
            RadioGroup radioGroup = findViewById(R.id.radioGroup);
            int checked = radioGroup.getCheckedRadioButtonId();

            if(BRL.equals("")){
                txtresult.setText("preencha o valor em reais!");
                Toast t = Toast.makeText(this, "preencha o valor em reais!", Toast.LENGTH_LONG);
                t.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL,0, 200);
                t.show();
            }
            else{
                Double real = Double.parseDouble(BRL);

                if(checked==R.id.USD){
                    Double result = real/5.75;
                    txtresult.setText("$ "+ result);

                } else if (checked == R.id.Euro) {
                    Double result = real / 6.09;
                    txtresult.setText("$ " + result);
                }

                else {
                    Double result = real/0.037;
                    txtresult.setText("$ "+result);


                }
            }
        }

    }
