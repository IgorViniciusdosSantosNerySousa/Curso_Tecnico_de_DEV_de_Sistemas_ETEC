package com.example.conversor2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText enterCoin;

    Button btnsonegar;

    TextView txtresult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        enterCoin = findViewById(R.id.enterCoin);
        btnsonegar = findViewById(R.id.btnsonegar);
        txtresult = findViewById(R.id.hide);

        btnsonegar.setOnClickListener(v ->{

            converter();

        });
    };

    private void converter(){
        String BRL = entradamoeda.getText().toString();
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        int checked = radioGroup.getCheckedRadioButtonId();

        if (BRL.equals("")){
            txtresultado.setText("Preencha o valor em reais!!");
          Toast t = Toast.makeText(this,
                  "preencha o valor em reais!!!",Toast.LENGTH_LONG);
          t.stGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL,
                  0.200);
          t.show();
        }else{
            Double real = Double.parseDouble(BRL);

              if(cheked == R.id.radioUSB){
                Double resultado = real/5.75;
                txtresultado.setText("$ "+resultado);


        }
    }

}