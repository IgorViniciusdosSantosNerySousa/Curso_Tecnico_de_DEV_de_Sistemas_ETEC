package com.example.calc_aposent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnCalcular ;
    TextView txtResult;
    EditText txtIdade, txtCont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCalcular = findViewById(R.id.btnCalcular);
        txtResult = findViewById(R.id.result);
        txtCont = findViewById(R.id.txtCont);
        txtIdade = findViewById(R.id.txtIdade);

        btnCalcular.setOnClickListener(v -> {
            calcular();
        });
    }
    private void calcular(){
        Editable idade = txtIdade.getText();
        Editable Cont = txtCont.getText();
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        int checked = radioGroup.getCheckedRadioButtonId();

        if(idade.equals("")){
            txtResult.setText("Preencha todos os Campos!!");
            Toast t = Toast.makeText(this, "Preencha todos os Campos!!", Toast.LENGTH_LONG);
            t.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 200);
            t.show();
        }else{
            int idade2 = Integer.parseInt(idade.toString());
            int Cont2 = Integer.parseInt(Cont.toString());

            if(checked == R.id.btnHomem){
                if (idade2 >= 65 && Cont2 > 34) {
                    txtResult.setText("Você pode se Aposentar!");
                } else {
                    txtResult.setText("Pode não Man...");
                }
            }

            if(checked == R.id.btnMulher){
                if (idade2 >= 60 && Cont2 > 29) {
                    txtResult.setText("Você pode se Aposentar!");
                } else {
                    txtResult.setText("Pode não Man...");
                }
            }
        }


    }
}

