package com.dsnoite.banco_nubank;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Extrato extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extrato);
    }
}